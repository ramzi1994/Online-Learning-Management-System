CREATE DATABASE IF NOT EXISTS online_lms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE online_lms;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('student','instructor','admin') NOT NULL DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    instructor_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE lessons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    content LONGTEXT NOT NULL,
    lesson_order INT DEFAULT 1,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    due_date DATE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    assignment_id INT NOT NULL,
    student_id INT NOT NULL,
    answer TEXT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    grade DECIMAL(5,2) NULL,
    feedback TEXT NULL,
    UNIQUE(assignment_id, student_id),
    FOREIGN KEY (assignment_id) REFERENCES assignments(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE quizzes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE quiz_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT NOT NULL,
    question TEXT NOT NULL,
    option_a VARCHAR(500) NOT NULL,
    option_b VARCHAR(500) NOT NULL,
    option_c VARCHAR(500) NOT NULL,
    option_d VARCHAR(500) NOT NULL,
    correct_option CHAR(1) NOT NULL,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

CREATE TABLE quiz_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT NOT NULL,
    student_id INT NOT NULL,
    score DECIMAL(5,2) NOT NULL,
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE lesson_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    lesson_id INT NOT NULL,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, lesson_id),
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
);

-- Demo accounts. Replace these password hashes if you change the passwords.
-- Password for all demo users: Password@123
INSERT INTO users(name,email,password,role) VALUES
('System Administrator','admin@lms.local','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3RoVJ8R8R0vQq5R3vM6j2Qm9y','admin'),
('Demo Instructor','instructor@lms.local','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3RoVJ8R8R0vQq5R3vM6j2Qm9y','instructor'),
('Demo Student','student@lms.local','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3RoVJ8R8R0vQq5R3vM6j2Qm9y','student');

INSERT INTO courses(title,description,instructor_id) VALUES
('Web Development Fundamentals','HTML, CSS, JavaScript and basic web application concepts.',2),
('Database Management Systems','Relational databases, SQL, keys, relationships and CRUD operations.',2);

INSERT INTO lessons(course_id,title,content,lesson_order) VALUES
(1,'Introduction to HTML','HTML provides the structure of a web page. Learn headings, paragraphs, links, images and forms.',1),
(1,'CSS Basics','CSS controls presentation, spacing, typography, layout and responsive design.',2),
(1,'JavaScript Basics','JavaScript adds behavior and interactivity to web pages.',3),
(2,'Introduction to SQL','SQL is used to create, read, update and delete relational data.',1),
(2,'Database Relationships','Primary and foreign keys connect related records between tables.',2);

INSERT INTO assignments(course_id,title,description,due_date) VALUES
(1,'Build a Student Page','Create a responsive student profile page using HTML and CSS.',DATE_ADD(CURDATE(),INTERVAL 14 DAY)),
(2,'Write SQL Queries','Write SELECT, INSERT, UPDATE and DELETE statements for a student database.',DATE_ADD(CURDATE(),INTERVAL 14 DAY));

INSERT INTO quizzes(course_id,title) VALUES
(1,'Web Basics Quiz'),
(2,'Database Basics Quiz');

INSERT INTO quiz_questions(quiz_id,question,option_a,option_b,option_c,option_d,correct_option) VALUES
(1,'What does HTML provide?','Database storage','Page structure','Operating system','Network routing','B'),
(1,'What does CSS mainly control?','Presentation and layout','Database indexing','Email delivery','Server hardware','A'),
(1,'Which language adds browser interactivity?','SQL','HTML','JavaScript','XML','C'),
(2,'Which command retrieves rows?','SELECT','REMOVE','FETCHROW','GETTABLE','A'),
(2,'Which key identifies a row uniquely?','Foreign key','Primary key','Index page','View key','B');
