# Online Learning Management System (LMS)

## Stack
- Frontend: HTML5 + CSS3
- Backend: PHP 8+ with PDO
- Database: MySQL 8+
- Server: Apache/XAMPP/WAMP/LAMP
- Authentication: PHP sessions + password_hash/password_verify

## Modules
1. Authentication and registration
2. Role-based access: student, instructor, admin
3. Course catalog and enrollment
4. Lessons and completion tracking
5. Assignments and submissions
6. Quizzes and automatic scoring
7. Student results
8. Instructor course/lesson/assignment management
9. Administrator user/course overview

## Installation
1. Install XAMPP or another PHP/MySQL environment.
2. Copy this folder into the web server document root, e.g. `htdocs/Online_LMS_Project`.
3. Start Apache and MySQL.
4. Open phpMyAdmin and import `database.sql`.
5. If your MySQL username/password differs from the default, edit `config.php`.
6. Open `http://localhost/Online_LMS_Project/`.
7. Demo student: student@lms.local / Password@123
8. Demo instructor: instructor@lms.local / Password@123
9. Demo admin: admin@lms.local / Password@123

## Security notes
This is an academic mini-project. Before production use, add CSRF protection, HTTPS, stronger authorization checks for every resource, upload validation, rate limiting, audit logging, secure cookie settings, and environment-based secrets.
