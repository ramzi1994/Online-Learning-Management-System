<?php
require_once '../config.php'; require_role('student');
$uid=$_SESSION['user']['id']; $cid=(int)($_GET['id']??0);
$stmt=$pdo->prepare("SELECT c.*,u.name instructor FROM courses c JOIN users u ON u.id=c.instructor_id JOIN enrollments e ON e.course_id=c.id WHERE c.id=? AND e.student_id=?");
$stmt->execute([$cid,$uid]); $course=$stmt->fetch(); if(!$course) exit('Course not found or not enrolled.');
$stmt=$pdo->prepare("SELECT l.*, EXISTS(SELECT 1 FROM lesson_progress p WHERE p.lesson_id=l.id AND p.student_id=?) completed FROM lessons l WHERE l.course_id=? ORDER BY l.lesson_order,l.id");
$stmt->execute([$uid,$cid]); $lessons=$stmt->fetchAll();
$a=$pdo->prepare("SELECT * FROM assignments WHERE course_id=? ORDER BY id DESC"); $a->execute([$cid]); $assignments=$a->fetchAll();
$q=$pdo->prepare("SELECT * FROM quizzes WHERE course_id=? ORDER BY id DESC"); $q->execute([$cid]); $quizzes=$q->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title><?=e($course['title'])?></title><link rel="stylesheet" href="../assets/style.css"></head><body>
<div class="topbar"><h1><?=e($course['title'])?></h1><a class="btn" href="dashboard.php">Dashboard</a></div><div class="container">
<p><?=e($course['description'])?></p><h2>Lessons</h2><?php foreach($lessons as $l): ?><div class="card"><h3><?=e($l['title'])?></h3><p><?=e(substr($l['content'],0,180))?>...</p><span class="badge"><?= $l['completed']?'Completed':'Not completed' ?></span> <a class="btn" href="lesson.php?id=<?=$l['id']?>">Open</a></div><br><?php endforeach; ?>
<h2>Assignments</h2><?php foreach($assignments as $x): ?><div class="card"><h3><?=e($x['title'])?></h3><p><?=e($x['description'])?></p><p>Due: <?=e($x['due_date'])?></p><a class="btn" href="assignment.php?id=<?=$x['id']?>">Submit</a></div><br><?php endforeach; ?>
<h2>Quizzes</h2><?php foreach($quizzes as $x): ?><div class="card"><h3><?=e($x['title'])?></h3><a class="btn" href="quiz.php?id=<?=$x['id']?>">Attempt Quiz</a></div><br><?php endforeach; ?>
</div></body></html>
