<?php
require_once '../config.php'; require_role('student');
$uid=$_SESSION['user']['id']; $lid=(int)($_GET['id']??0);
$stmt=$pdo->prepare("SELECT l.*,c.title course FROM lessons l JOIN courses c ON c.id=l.course_id JOIN enrollments e ON e.course_id=c.id WHERE l.id=? AND e.student_id=?");
$stmt->execute([$lid,$uid]); $lesson=$stmt->fetch(); if(!$lesson) exit('Lesson not found.');
if($_SERVER['REQUEST_METHOD']==='POST'){
    $stmt=$pdo->prepare("INSERT IGNORE INTO lesson_progress(student_id,lesson_id) VALUES(?,?)");
    $stmt->execute([$uid,$lid]); $done=true;
} else $done=false;
?>
<!doctype html><html><head><meta charset="utf-8"><title>Lesson</title><link rel="stylesheet" href="../assets/style.css"></head><body><div class="container">
<div class="card"><h2><?=e($lesson['title'])?></h2><p class="muted"><?=e($lesson['course'])?></p><div><?=nl2br(e($lesson['content']))?></div>
<form method="post"><button class="btn"><?=$done?'Completed':'Mark as Completed'?></button></form><a href="course.php?id=<?=$lesson['course_id']?>">Back to course</a></div></div></body></html>
