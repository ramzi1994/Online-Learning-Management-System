<?php
require_once '../config.php'; require_role('student');
$uid=$_SESSION['user']['id']; $msg='';
if(isset($_GET['enroll'])) {
    $cid=(int)$_GET['enroll'];
    $stmt=$pdo->prepare("INSERT IGNORE INTO enrollments(student_id,course_id) VALUES(?,?)");
    $stmt->execute([$uid,$cid]); $msg='Course enrolled successfully.';
}
$stmt=$pdo->prepare("SELECT c.*,u.name instructor, EXISTS(SELECT 1 FROM enrollments e WHERE e.course_id=c.id AND e.student_id=?) enrolled FROM courses c JOIN users u ON u.id=c.instructor_id ORDER BY c.id DESC");
$stmt->execute([$uid]); $courses=$stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Courses</title><link rel="stylesheet" href="../assets/style.css"></head><body>
<div class="topbar"><h1>Course Catalog</h1><a class="btn" href="../logout.php">Logout</a></div><div class="container">
<?php if($msg): ?><div class="success"><?=e($msg)?></div><?php endif; ?><div class="grid">
<?php foreach($courses as $c): ?><div class="card"><h3><?=e($c['title'])?></h3><p><?=e($c['description'])?></p><p class="muted">Instructor: <?=e($c['instructor'])?></p>
<?php if($c['enrolled']): ?><span class="badge">Enrolled</span> <a class="btn" href="course.php?id=<?=$c['id']?>">Open</a><?php else: ?><a class="btn" href="?enroll=<?=$c['id']?>">Enroll</a><?php endif; ?></div><?php endforeach; ?>
</div></div></body></html>
