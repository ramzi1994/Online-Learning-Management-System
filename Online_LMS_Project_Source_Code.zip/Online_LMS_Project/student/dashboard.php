<?php
require_once '../config.php'; require_role('student');
$uid=$_SESSION['user']['id'];
$stmt=$pdo->prepare("SELECT c.*,u.name instructor FROM courses c JOIN enrollments e ON e.course_id=c.id JOIN users u ON u.id=c.instructor_id WHERE e.student_id=? ORDER BY c.id DESC");
$stmt->execute([$uid]); $courses=$stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Student Dashboard</title><link rel="stylesheet" href="../assets/style.css"></head><body>
<div class="topbar"><h1>Student Dashboard</h1><a class="btn" href="../logout.php">Logout</a></div>
<div class="nav"><a href="dashboard.php">Dashboard</a><a href="courses.php">Browse Courses</a><a href="results.php">Results</a></div>
<div class="container"><h2>Welcome, <?=e($_SESSION['user']['name'])?></h2><div class="grid">
<?php foreach($courses as $c): ?><div class="card"><h3><?=e($c['title'])?></h3><p><?=e($c['description'])?></p><p class="muted">Instructor: <?=e($c['instructor'])?></p><a class="btn" href="course.php?id=<?=$c['id']?>">Open Course</a></div><?php endforeach; ?>
</div></div></body></html>
