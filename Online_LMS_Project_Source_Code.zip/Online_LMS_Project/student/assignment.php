<?php
require_once '../config.php'; require_role('student');
$uid=$_SESSION['user']['id']; $aid=(int)($_GET['id']??0); $msg='';
$stmt=$pdo->prepare("SELECT a.*,c.title course FROM assignments a JOIN courses c ON c.id=a.course_id JOIN enrollments e ON e.course_id=c.id WHERE a.id=? AND e.student_id=?");
$stmt->execute([$aid,$uid]); $a=$stmt->fetch(); if(!$a) exit('Assignment not found.');
if($_SERVER['REQUEST_METHOD']==='POST'){
    $answer=trim($_POST['answer']??'');
    $stmt=$pdo->prepare("INSERT INTO submissions(assignment_id,student_id,answer) VALUES(?,?,?) ON DUPLICATE KEY UPDATE answer=VALUES(answer),submitted_at=CURRENT_TIMESTAMP");
    $stmt->execute([$aid,$uid,$answer]); $msg='Assignment submitted successfully.';
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Assignment</title><link rel="stylesheet" href="../assets/style.css"></head><body><div class="container"><div class="card">
<h2><?=e($a['title'])?></h2><p><?=e($a['description'])?></p><p>Due: <?=e($a['due_date'])?></p>
<?php if($msg): ?><div class="success"><?=e($msg)?></div><?php endif; ?><form method="post"><label>Your Answer</label><textarea name="answer" required></textarea><button class="btn">Submit Assignment</button></form></div></div></body></html>
