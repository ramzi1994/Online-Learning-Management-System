<?php
require_once '../config.php'; require_role('student');
$uid=$_SESSION['user']['id']; $qid=(int)($_GET['id']??0);
$stmt=$pdo->prepare("SELECT q.*,c.title course FROM quizzes q JOIN courses c ON c.id=q.course_id JOIN enrollments e ON e.course_id=c.id WHERE q.id=? AND e.student_id=?");
$stmt->execute([$qid,$uid]); $quiz=$stmt->fetch(); if(!$quiz) exit('Quiz not found.');
$stmt=$pdo->prepare("SELECT * FROM quiz_questions WHERE quiz_id=? ORDER BY id"); $stmt->execute([$qid]); $questions=$stmt->fetchAll();
$result=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
    $score=0; foreach($questions as $q){ if(($_POST['q'.$q['id']]??'')===$q['correct_option']) $score++; }
    $percent=count($questions)?round($score/count($questions)*100,2):0;
    $stmt=$pdo->prepare("INSERT INTO quiz_attempts(quiz_id,student_id,score) VALUES(?,?,?)");
    $stmt->execute([$qid,$uid,$percent]); $result=$percent;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Quiz</title><link rel="stylesheet" href="../assets/style.css"></head><body><div class="container"><div class="card">
<h2><?=e($quiz['title'])?></h2><?php if($result!==null): ?><div class="success">Your score: <?=e($result)?>%</div><?php endif; ?>
<form method="post"><?php foreach($questions as $i=>$q): ?><div class="question"><strong><?=($i+1)?>. <?=e($q['question'])?></strong>
<label><input type="radio" name="q<?=$q['id']?>" value="A" required> <?=e($q['option_a'])?></label>
<label><input type="radio" name="q<?=$q['id']?>" value="B"> <?=e($q['option_b'])?></label>
<label><input type="radio" name="q<?=$q['id']?>" value="C"> <?=e($q['option_c'])?></label>
<label><input type="radio" name="q<?=$q['id']?>" value="D"> <?=e($q['option_d'])?></label></div><?php endforeach; ?><button class="btn">Submit Quiz</button></form>
</div></div></body></html>
