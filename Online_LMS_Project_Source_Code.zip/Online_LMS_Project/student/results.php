<?php
require_once '../config.php'; require_role('student');
$uid=$_SESSION['user']['id'];
$stmt=$pdo->prepare("SELECT q.title,a.score,a.attempted_at FROM quiz_attempts a JOIN quizzes q ON q.id=a.quiz_id WHERE a.student_id=? ORDER BY a.attempted_at DESC");
$stmt->execute([$uid]); $results=$stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Results</title><link rel="stylesheet" href="../assets/style.css"></head><body><div class="container"><div class="card">
<h2>Quiz Results</h2><div class="table-wrap"><table><tr><th>Quiz</th><th>Score</th><th>Date</th></tr>
<?php foreach($results as $r): ?><tr><td><?=e($r['title'])?></td><td><?=e($r['score'])?>%</td><td><?=e($r['attempted_at'])?></td></tr><?php endforeach; ?>
</table></div></div></div></body></html>
