<?php
require_once '../config.php'; require_role('admin');
$users=$pdo->query("SELECT id,name,email,role,created_at FROM users ORDER BY id DESC")->fetchAll();
$courses=$pdo->query("SELECT c.id,c.title,u.name instructor FROM courses c JOIN users u ON u.id=c.instructor_id ORDER BY c.id DESC")->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Dashboard</title><link rel="stylesheet" href="../assets/style.css"></head><body>
<div class="topbar"><h1>Administrator Dashboard</h1><a class="btn" href="../logout.php">Logout</a></div><div class="container">
<div class="card"><h2>Users</h2><div class="table-wrap"><table><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr><?php foreach($users as $u): ?><tr><td><?=$u['id']?></td><td><?=e($u['name'])?></td><td><?=e($u['email'])?></td><td><?=e($u['role'])?></td></tr><?php endforeach; ?></table></div></div>
<div class="card"><h2>Courses</h2><div class="table-wrap"><table><tr><th>Title</th><th>Instructor</th></tr><?php foreach($courses as $c): ?><tr><td><?=e($c['title'])?></td><td><?=e($c['instructor'])?></td></tr><?php endforeach; ?></table></div></div>
</div></body></html>
