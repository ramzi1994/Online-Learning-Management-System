<?php
session_start();

$host = 'localhost';
$db   = 'online_lms';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    exit("Database connection failed. Check config.php and MySQL.");
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function require_login() {
    if (!isset($_SESSION['user'])) {
        header('Location: login.php');
        exit;
    }
}

function require_role($roles) {
    require_login();
    if (!in_array($_SESSION['user']['role'], (array)$roles, true)) {
        http_response_code(403);
        exit('Access denied.');
    }
}

function redirect_by_role() {
    $role = $_SESSION['user']['role'] ?? '';
    if ($role === 'admin') header('Location: admin/dashboard.php');
    elseif ($role === 'instructor') header('Location: instructor/dashboard.php');
    else header('Location: student/dashboard.php');
    exit;
}
?>
