<?php
require_once 'config.php';
if (isset($_SESSION['user'])) redirect_by_role();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT id,name,email,password,role FROM users WHERE email=? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        unset($user['password']);
        session_regenerate_id(true);
        $_SESSION['user'] = $user;
        redirect_by_role();
    }
    $error = 'Invalid email or password.';
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Login</title><link rel="stylesheet" href="assets/style.css"></head>
<body><div class="card form-card"><h2>LMS Login</h2>
<?php if(isset($_GET['registered'])): ?><div class="success">Registration successful. Please log in.</div><?php endif; ?>
<?php if($error): ?><div class="error"><?=e($error)?></div><?php endif; ?>
<form method="post">
<label>Email</label><input type="email" name="email" required>
<label>Password</label><input type="password" name="password" required>
<button class="btn">Login</button>
</form>
<p>Demo: student@lms.local / Password@123</p>
<p><a href="register.php">Create student account</a></p></div></body></html>
