<?php
require_once '../config.php'; require_role('instructor');
if($_SERVER['REQUEST_METHOD']==='POST'){
    $stmt=$pdo->prepare("INSERT INTO courses(title,description,instructor_id) VALUES(?,?,?)");
    $stmt->execute([trim($_POST['title']),trim($_POST['description']),$_SESSION['user']['id']]);
    header('Location: dashboard.php'); exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Create Course</title><link rel="stylesheet" href="../assets/style.css"></head><body><div class="container"><div class="card">
<h2>Create Course</h2><form method="post"><label>Title</label><input name="title" required><label>Description</label><textarea name="description"></textarea><button class="btn">Save Course</button></form></div></div></body></html>
