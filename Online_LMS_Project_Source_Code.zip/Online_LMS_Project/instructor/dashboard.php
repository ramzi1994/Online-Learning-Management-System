<?php
require_once '../config.php'; require_role('instructor');
$uid=$_SESSION['user']['id'];
$stmt=$pdo->prepare("SELECT * FROM courses WHERE instructor_id=? ORDER BY id DESC"); $stmt->execute([$uid]); $courses=$stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Instructor Dashboard</title><link rel="stylesheet" href="../assets/style.css"></head><body>
<div class="topbar"><h1>Instructor Dashboard</h1><a class="btn" href="../logout.php">Logout</a></div><div class="container">
<a class="btn" href="course_create.php">Create Course</a><div class="grid">
<?php foreach($courses as $c): ?><div class="card"><h3><?=e($c['title'])?></h3><p><?=e($c['description'])?></p><a class="btn" href="course_manage.php?id=<?=$c['id']?>">Manage</a></div><?php endforeach; ?>
</div></div></body></html>
