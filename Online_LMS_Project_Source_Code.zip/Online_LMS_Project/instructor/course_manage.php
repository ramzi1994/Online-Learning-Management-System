<?php
require_once '../config.php'; require_role('instructor');
$uid=$_SESSION['user']['id']; $cid=(int)($_GET['id']??0);
$stmt=$pdo->prepare("SELECT * FROM courses WHERE id=? AND instructor_id=?"); $stmt->execute([$cid,$uid]); $course=$stmt->fetch(); if(!$course) exit('Course not found.');
if($_SERVER['REQUEST_METHOD']==='POST'){
    if($_POST['type']==='lesson'){
        $s=$pdo->prepare("INSERT INTO lessons(course_id,title,content,lesson_order) VALUES(?,?,?,?)");
        $s->execute([$cid,trim($_POST['title']),trim($_POST['content']),(int)$_POST['lesson_order']]);
    } elseif($_POST['type']==='assignment'){
        $s=$pdo->prepare("INSERT INTO assignments(course_id,title,description,due_date) VALUES(?,?,?,?)");
        $s->execute([$cid,trim($_POST['title']),trim($_POST['description']),$_POST['due_date']]);
    }
}
$l=$pdo->prepare("SELECT * FROM lessons WHERE course_id=? ORDER BY lesson_order");$l->execute([$cid]);$lessons=$l->fetchAll();
$a=$pdo->prepare("SELECT * FROM assignments WHERE course_id=? ORDER BY id DESC");$a->execute([$cid]);$assignments=$a->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Manage Course</title><link rel="stylesheet" href="../assets/style.css"></head><body><div class="container">
<div class="card"><h2><?=e($course['title'])?></h2><h3>Add Lesson</h3><form method="post"><input type="hidden" name="type" value="lesson"><label>Title</label><input name="title" required><label>Content</label><textarea name="content" required></textarea><label>Order</label><input type="number" name="lesson_order" value="1"><button class="btn">Add Lesson</button></form>
<hr><h3>Add Assignment</h3><form method="post"><input type="hidden" name="type" value="assignment"><label>Title</label><input name="title" required><label>Description</label><textarea name="description"></textarea><label>Due Date</label><input type="date" name="due_date"><button class="btn">Add Assignment</button></form></div>
<div class="card"><h3>Lessons</h3><?php foreach($lessons as $x): ?><p><?=e($x['lesson_order'])?>. <?=e($x['title'])?></p><?php endforeach; ?></div>
<div class="card"><h3>Assignments</h3><?php foreach($assignments as $x): ?><p><?=e($x['title'])?> — <?=e($x['due_date'])?></p><?php endforeach; ?></div>
</div></body></html>
