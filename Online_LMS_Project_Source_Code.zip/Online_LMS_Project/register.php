<?php
require_once 'config.php';
if (isset($_SESSION['user'])) redirect_by_role();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
        $error = 'Enter a valid name, email and password of at least 8 characters.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email=?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email already registered.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'student')");
            $stmt->execute([$name,$email,$hash]);
            header('Location: login.php?registered=1');
            exit;
        }
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Register</title><link rel="stylesheet" href="assets/style.css"></head>
<body><div class="card form-card"><h2>Student Registration</h2>
<?php if($error): ?><div class="error"><?=e($error)?></div><?php endif; ?>
<form method="post">
<label>Name</label><input name="name" required>
<label>Email</label><input type="email" name="email" required>
<label>Password</label><input type="password" name="password" minlength="8" required>
<button class="btn">Register</button>
</form><p><a href="login.php">Already have an account?</a></p></div></body></html>
