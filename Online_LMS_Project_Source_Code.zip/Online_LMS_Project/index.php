<?php
require_once 'config.php';
if (isset($_SESSION['user'])) redirect_by_role();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Online LMS</title><link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar"><h1>Online Learning Management System</h1><a class="btn" href="login.php">Login</a></header>
<main class="hero">
<h2>Learn. Practice. Progress.</h2>
<p>A centralized platform for courses, lessons, assignments, quizzes, progress and results.</p>
<a class="btn" href="register.php">Create Student Account</a>
</main>
</body></html>
